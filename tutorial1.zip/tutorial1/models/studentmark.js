const Sequelize = require('sequelize');
const sequelize = require('../utils/dbconnect');

const Studentmark = sequelize.define('Studentmark', { // Model name
    id: { type: Sequelize.UUID, primaryKey: true },
    subjectname: { type: Sequelize.STRING, allowNull: false },
    assignmentname: { type: Sequelize.STRING, allowNull: false },
    marks: { type: Sequelize.INTEGER, allowNull: false },
}, {
    tableName: 'Studentmarks', 
    timestamps: false, 
});

module.exports = Studentmark;